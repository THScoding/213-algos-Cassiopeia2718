These are starter code stubs to facilitate following the PLTW curriculumn Activities
