public class WhileAndFor
{
  public static void main(String[] args)
  {
    System.out.println("\n while loop, -10 to 10 by 1s");
    int i = -10;
    while (i <= 10)
    {
      System.out.println(i);
      i += 1;
    }
    
    System.out.println("\n for loop, -10 to 10 by 1s");
    //TODO: Step 18: Implement for loop version of preceding while loop:


    System.out.println("\n for loop, 0-50 by 5s");
    //TODO: Step 19: Implement for loop:

    
    System.out.println("\nwhile loop, 0-50 by 5s");
    //TODO: Step 20: Implement while loop:

  }
}