/*
 * Activity 2.1.3
 */

public class Dyslexia
{
  public static void main(String[] args)
  {
    String testInput = "Bob decided it was time to do something different. Tired and stressed, Bob dreamed of traveling the world. He wanted to meet new people, experience cultures, and see distant lands. He hoped he could afford an extended trip, so he called a friendly travel agent.";
    System.out.println(randomSubstitute(testInput));
  }
  
  private static String randomSubstitute(String input) {
    String output = "";
    //TODO: Write your code here

    return output;
  }
}