import java.util.Scanner;

public class EveryOtherChar 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String: ");
        String input = sc.nextLine();
        String output = "";
 
        //TODO:  Insert your code here to transform the input String
      
        System.out.println(output);

        sc.close();
    }
}
