/*
 * Activity 2.1.3
 */
import java.util.Scanner;

public class Anagram
{
  public static void main(String[] args)
  {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String: ");
        String input = sc.nextLine();

        
    /*
    
    
    */

  }
}